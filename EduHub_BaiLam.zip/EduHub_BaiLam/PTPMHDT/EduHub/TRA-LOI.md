﻿
# BÀI KIỂM TRA GIỮA HỌC PHẦN IN4211

## Câu 1a. Bốn trụ cột của lập trình hướng đối tượng

**1. Tính đóng gói (Encapsulation)**

Là nguyên lý che giấu dữ liệu bên trong đối tượng và chỉ cho phép truy cập thông qua các phương thức được cung cấp. Trong bài làm, lớp `Member` ở tệp `Member.cs` sử dụng `private set` để bảo vệ các thuộc tính `Id` và `Email`. Việc tạo đối tượng được thực hiện thông qua factory method `Create()` để kiểm tra dữ liệu đầu vào.

**2. Tính kế thừa (Inheritance)**

Là khả năng một lớp kế thừa từ lớp cha để sử dụng lại thuộc tính và phương thức, đồng thời có thể mở rộng hành vi. Trong bài làm, lớp `EventsController` trong tệp `Controllers.cs` kế thừa `ControllerBase` của ASP.NET Core để sử dụng các chức năng nền tảng của controller.

**3. Tính đa hình (Polymorphism)**

Là khả năng cùng một lời gọi phương thức nhưng có thể thực hiện những hành vi khác nhau tùy đối tượng cụ thể. Trong bài làm, `EmailNotificationService` và `SmsNotificationService` cùng triển khai phương thức `Send()` của `INotificationService`, nhưng mỗi lớp có cách gửi thông báo khác nhau.

**4. Tính trừu tượng (Abstraction)**

Là việc tập trung thể hiện những chức năng cần thiết và ẩn đi cách thức triển khai bên trong. Trong bài làm, interface `IEventRepository` chỉ khai báo các thao tác lưu trữ sự kiện mà không thể hiện chi tiết cách lưu dữ liệu.

## Câu 1b. Các vấn đề của lớp Member

Lớp `Member` ban đầu có hai vấn đề:

- Thứ nhất, hai thuộc tính `Id` và `Email` sử dụng `public set`, cho phép các lớp bên ngoài tự ý thay đổi dữ liệu, làm mất tính đóng gói.
- Thứ hai, constructor `public Member()` cho phép tạo đối tượng mà không cần kiểm tra dữ liệu. Vì vậy, email không hợp lệ như "abc" vẫn có thể được gán cho đối tượng.

Cách khắc phục: Sử dụng `private set`, constructor `private` và factory method `Create()` để kiểm tra email không được rỗng và phải chứa ký tự `@`. Nếu dữ liệu không hợp lệ, phương thức sẽ ném `ArgumentException`.

## Câu 2a. Sơ đồ trạng thái của Registration

```mermaid
stateDiagram-v2
    [*] --> Pending: Create()
    Pending --> Confirmed: Confirm()
    Pending --> Cancelled: Cancel()
    Confirmed --> Cancelled: Cancel()
    Cancelled --> [*]
```

Trạng thái `Cancelled` là trạng thái cuối cùng. Phiếu đăng ký đã bị hủy không thể xác nhận hoặc thay đổi trạng thái thêm lần nữa.

## Câu 2b. Mô hình hóa và cài đặt Registration

Lớp `Registration` có các thuộc tính `Id`, `MemberId`, `EventId`, `RegisteredAt` và `Status`. Các thuộc tính chỉ được sửa bên trong lớp thông qua `private set`. `RegisteredAt` được gán thời điểm UTC khi tạo phiếu.

Enum `RegistrationStatus` gồm ba trạng thái: `Pending`, `Confirmed` và `Cancelled`.

Constructor của lớp được khai báo `private` nhằm hạn chế việc tạo đối tượng trực tiếp. Factory method `Create(Guid memberId, Guid eventId)` kiểm tra hai mã `MemberId` và `EventId` không được bằng `Guid.Empty`, đồng thời khởi tạo trạng thái ban đầu là `Pending`. Nếu dữ liệu không hợp lệ, phương thức ném `ArgumentException`.

Phương thức `Confirm()` chỉ cho phép xác nhận khi trạng thái hiện tại là `Pending`, sau đó chuyển sang `Confirmed`.

Phương thức `Cancel()` cho phép hủy khi trạng thái là `Pending` hoặc `Confirmed`, sau đó chuyển sang `Cancelled`. Nếu trạng thái không phù hợp, chương trình ném `InvalidOperationException`.

## Câu 2c. Kiểm thử Registration

Các bài kiểm thử được thực hiện bằng thư viện xUnit nhằm kiểm tra những trường hợp:

- Tạo Registration hợp lệ thì trạng thái ban đầu là `Pending`.
- Tạo Registration với `MemberId` bằng `Guid.Empty` thì phát sinh `ArgumentException`.
- Hủy Registration rồi gọi `Confirm()` thì phát sinh `InvalidOperationException` và trạng thái vẫn là `Cancelled`.

Các kiểm thử giúp đảm bảo những quy tắc chuyển trạng thái của Registration được thực hiện đúng.

## Câu 3a. Các nguyên lý SOLID bị vi phạm

**1. Single Responsibility Principle (SRP) – Nguyên lý đơn trách nhiệm**

Vi phạm ở dòng 6–14. Lớp `EventService` đảm nhận nhiều công việc như kiểm tra dữ liệu, kết nối cơ sở dữ liệu SQL, ghi log và gửi thông báo. Một lớp có quá nhiều trách nhiệm sẽ khó bảo trì và thay đổi.

**2. Open/Closed Principle (OCP) – Nguyên lý đóng/mở**

Vi phạm ở dòng 11–14. Khi muốn bổ sung một kênh thông báo mới, phải sửa câu lệnh `if-else` hiện tại. Điều này khiến lớp chưa thuận lợi cho việc mở rộng mà không sửa đổi mã nguồn cũ.

**3. Dependency Inversion Principle (DIP) – Nguyên lý đảo ngược phụ thuộc**

Vi phạm ở dòng 8, 12 và 14. `EventService` phụ thuộc trực tiếp vào các lớp cụ thể như `SqlConnection`, `EmailSender` và `SmsSender` thay vì phụ thuộc vào các interface trừu tượng.

## Câu 3b. Cài đặt lại EventService

Để khắc phục các vi phạm SOLID, chương trình được tổ chức lại thành các thành phần:

- **Event:** Entity thuộc `EduHub.Domain`, có factory method `Create()` để kiểm tra tiêu đề không được rỗng và sức chứa phải lớn hơn 0.
- **IEventRepository:** Interface thuộc `EduHub.Application`, khai báo các thao tác lưu trữ sự kiện.
- **InMemoryEventRepository:** Lớp thuộc `EduHub.Infrastructure`, triển khai `IEventRepository` và lưu sự kiện trong bộ nhớ.
- **INotificationService:** Interface thuộc `EduHub.Application`, khai báo phương thức gửi thông báo.
- **EmailNotificationService:** Lớp thuộc `EduHub.Infrastructure`, triển khai gửi thông báo qua email bằng cách in nội dung ra Console.
- **SmsNotificationService:** Lớp thuộc `EduHub.Infrastructure`, triển khai gửi thông báo qua SMS bằng cách in nội dung ra Console.
- **NotificationFactory:** Chọn dịch vụ thông báo phù hợp dựa trên giá trị `channel`.
- **EventService:** Nhận các phụ thuộc thông qua constructor injection, không trực tiếp khởi tạo các lớp cụ thể bằng từ khóa `new`.

Các dịch vụ được đăng ký trong `Program.cs` thông qua Dependency Injection. Cách tổ chức này giúp tách biệt trách nhiệm, thuận tiện mở rộng và giảm sự phụ thuộc giữa các lớp.

## Câu 3c. Kiểm thử EventService bằng Moq

Sử dụng thư viện xUnit kết hợp với Moq để giả lập `IEventRepository` và `INotificationService`.

Khi gọi phương thức tạo sự kiện với dữ liệu hợp lệ, bài kiểm thử cần xác nhận:

- Phương thức `Add()` của repository được gọi đúng một lần.
- Phương thức `Send()` của dịch vụ thông báo được gọi đúng một lần.

Việc kiểm thử giúp đảm bảo `EventService` thực hiện đúng thao tác lưu sự kiện và gửi thông báo mà không cần kết nối cơ sở dữ liệu hoặc gửi thông báo thật.

## Câu 4a. Lịch sử Git và Pull Request

Quá trình quản lý mã nguồn được thực hiện bằng Git và GitHub theo các yêu cầu:

- Tạo repository công khai có tên `IN4211-GK-<MSSV>`.
- Tạo solution `EduHub` và thêm tệp `.gitignore` để loại trừ các thư mục `bin/` và `obj/`.
- Commit khởi tạo nằm trên nhánh `main`; các thay đổi bài làm được thực hiện trên nhánh `midterm/0024415443`.
- Không commit trực tiếp các thay đổi bài làm lên nhánh `main`.
- Có ít nhất 5 commit, mỗi commit tập trung vào một công việc cụ thể.
- Sử dụng quy ước Conventional Commits, ví dụ:
  - `feat(domain): add Member entity`
  - `feat(domain): add Registration entity`
  - `test(registration): add registration unit tests`
  - `feat(application): refactor EventService`
  - `feat(api): add EventsController endpoints`
- Push nhánh `midterm/<MSSV>` lên GitHub và tạo Pull Request vào nhánh `main`, kèm mô tả ngắn về những nội dung đã thực hiện.

## Câu 4b. Phân biệt git merge và git rebase

**git merge:**

Dùng để kết hợp những thay đổi từ hai nhánh Git. Lệnh này giữ lại lịch sử phân nhánh và có thể tạo một merge commit.

**git rebase:**

Dùng để đưa các commit của nhánh hiện tại sang vị trí mới dựa trên một nhánh khác, giúp lịch sử commit trở nên thẳng và gọn hơn.

**Khi nào không nên dùng rebase?**

Không nên sử dụng rebase đối với nhánh đã được chia sẻ và nhiều người cùng làm việc vì lệnh này viết lại lịch sử commit, có thể gây xung đột và ảnh hưởng đến những người khác.

## Câu 5a. Sơ đồ kiến trúc Clean Architecture

Solution EduHub được chia thành bốn lớp:

- **Domain:** Chứa các Entity như `Event`, `Member`, `Registration` và các quy tắc nghiệp vụ.
- **Application:** Chứa interface `IEventRepository`, `INotificationService` và lớp `EventService`.
- **Infrastructure:** Chứa `InMemoryEventRepository`, `EmailNotificationService`, `SmsNotificationService` và `NotificationFactory`.
- **API:** Chứa `EventsController`, tiếp nhận và xử lý các yêu cầu HTTP.

**Sơ đồ phụ thuộc:**

```mermaid
flowchart TD
    API["EduHub.API - EventsController"]
    APP["EduHub.Application - IEventRepository, INotificationService, EventService"]
    INFRA["EduHub.Infrastructure - InMemoryEventRepository, EmailNotificationService, SmsNotificationService"]
    DOMAIN["EduHub.Domain - Event, Member, Registration"]

    API --> APP
    API --> INFRA
    INFRA --> APP
    INFRA --> DOMAIN
    APP --> DOMAIN
```

**Các lệnh thiết lập tham chiếu giữa project:**

```bash
dotnet add EduHub.Application reference EduHub.Domain
dotnet add EduHub.Infrastructure reference EduHub.Domain
dotnet add EduHub.Infrastructure reference EduHub.Application
dotnet add EduHub.API reference EduHub.Application
dotnet add EduHub.API reference EduHub.Infrastructure
```

Chiều phụ thuộc được tổ chức từ các lớp bên ngoài hướng vào các lớp bên trong. Domain không phụ thuộc vào các lớp bên ngoài.

## Câu 5b. Vì sao Domain không được tham chiếu Infrastructure?

Project `EduHub.Domain` chứa các thực thể và quy tắc nghiệp vụ cốt lõi nên không được phụ thuộc vào `EduHub.Infrastructure`.

Nếu Domain tham chiếu Infrastructure, các quy tắc nghiệp vụ sẽ bị phụ thuộc vào cách triển khai lưu trữ dữ liệu hoặc các công nghệ bên ngoài. Điều này làm giảm tính độc lập, khả năng tái sử dụng và bảo trì của hệ thống, đồng thời vi phạm nguyên tắc Dependency Rule trong Clean Architecture.

## Câu 5c. Các endpoint của EventsController

EventsController cung cấp bốn endpoint để quản lý sự kiện của câu lạc bộ:

| Chức năng | Phương thức và route |
|---|---|
| Lấy danh sách sự kiện của câu lạc bộ | GET `/api/clubs/{clubId}/events` |
| Xem một sự kiện theo Id | GET `/api/events/{id}` |
| Tạo sự kiện mới cho câu lạc bộ | POST `/api/clubs/{clubId}/events` |
| Xóa một sự kiện | DELETE `/api/events/{id}` |

Các endpoint được kiểm tra bằng Swagger. Kết quả kiểm thử đã thực hiện:

- POST tạo sự kiện thành công, trả về HTTP 201 Created.
- GET sự kiện theo Id thành công, trả về HTTP 200 OK.
- GET danh sách sự kiện của câu lạc bộ thành công, trả về HTTP 200 OK.
- DELETE sự kiện thành công, trả về HTTP 204 No Content.
- GET sự kiện sau khi đã xóa trả về HTTP 404 Not Found.

Các ảnh chụp màn hình kiểm thử thành công và kiểm thử lỗi được lưu trong thư mục `MinhChung/` của repository.

## Câu 5d. Giải thích lỗi InMemoryEventRepository khi dùng AddScoped

Khi đăng ký `InMemoryEventRepository` bằng `AddScoped`, mỗi HTTP request sẽ tạo một instance repository riêng. Vì dữ liệu được lưu trong một `List<Event>` thông thường, không phải `static`, nên danh sách chỉ tồn tại trong instance của request hiện tại.

Do đó, khi gọi POST để thêm sự kiện, dữ liệu được lưu vào danh sách của request POST. Khi gọi GET tiếp theo, một instance mới được tạo với danh sách rỗng nên không tìm thấy dữ liệu vừa thêm.

Cách khắc phục: Sử dụng `AddSingleton` để toàn bộ ứng dụng dùng chung một instance `InMemoryEventRepository`, nhờ đó dữ liệu trong danh sách được duy trì giữa các request khi ứng dụng còn chạy.
