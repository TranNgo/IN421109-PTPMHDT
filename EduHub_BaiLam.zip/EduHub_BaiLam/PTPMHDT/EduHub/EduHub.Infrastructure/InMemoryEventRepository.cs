﻿
using System;
using System.Collections.Generic;
using System.Linq;
using EduHub.Domain.Entities;
using EduHub.Application.Interfaces;

namespace EduHub.Infrastructure.Repositories
{
    public class InMemoryEventRepository : IEventRepository
    {
        private readonly List<Event> _events = new List<Event>();

        public void Add(Event newEvent)
        {
            _events.Add(newEvent);
        }

        public Event GetById(Guid id)
        {
            return _events.FirstOrDefault(e => e.Id == id);
        }

        public IEnumerable<Event> GetByClubId(Guid clubId)
        {
            return _events.Where(e => e.ClubId == clubId).ToList();
        }

        public void Delete(Guid id)
        {
            var eventItem = GetById(id);

            if (eventItem != null)
            {
                _events.Remove(eventItem);
            }
        }
    }
}
