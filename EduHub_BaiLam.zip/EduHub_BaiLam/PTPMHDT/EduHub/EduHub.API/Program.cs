﻿using EduHub.Application.Interfaces;
using EduHub.Application.Services;
using EduHub.Infrastructure.Repositories;
using EduHub.Infrastructure.Notifications;

var builder = WebApplication.CreateBuilder(args);

// Dùng Singleton để dữ liệu List<Event> tồn tại giữa các HTTP request.
builder.Services.AddSingleton<IEventRepository, InMemoryEventRepository>();

// Factory chọn dịch vụ thông báo theo kênh cấu hình.
builder.Services.AddScoped<INotificationService>(_ =>
    NotificationFactory.Create(builder.Configuration["Notification:Channel"] ?? "email"));
builder.Services.AddScoped<EventService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
