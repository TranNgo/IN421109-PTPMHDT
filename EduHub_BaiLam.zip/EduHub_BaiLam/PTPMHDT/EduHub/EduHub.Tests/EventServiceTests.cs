﻿
using System;
using Moq;
using Xunit;
using EduHub.Application.Interfaces;
using EduHub.Application.Services;
using EduHub.Domain.Entities;

namespace EduHub.Tests
{
    public class EventServiceTests
    {
        [Fact]
        public void CreateEvent_ValidData_ShouldAddAndSendOnce()
        {
            // Arrange
            var repository = new Mock<IEventRepository>();
            var notification = new Mock<INotificationService>();

            var service = new EventService(
                repository.Object,
                notification.Object);

            // Act
            service.CreateEvent(
                Guid.NewGuid(),
                "Workshop C#",
                DateTime.Now,
                50);

            // Assert
            repository.Verify(
                x => x.Add(It.IsAny<Event>()),
                Times.Once);

            notification.Verify(
                x => x.Send(It.IsAny<string>()),
                Times.Once);
        }
    }
}

