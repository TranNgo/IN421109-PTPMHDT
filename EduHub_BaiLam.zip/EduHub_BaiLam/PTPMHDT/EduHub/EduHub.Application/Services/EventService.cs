﻿using EduHub.Application.Interfaces;
using EduHub.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace EduHub.Application.Services
{
    public class EventService
    {
        private readonly IEventRepository _repository;
        private readonly INotificationService _notification;

        public EventService(
            IEventRepository repository,
            INotificationService notification)
        {
            _repository = repository;
            _notification = notification;
        }

        public void CreateEvent(
            Guid clubId,
            string title,
            DateTime date,
            int capacity)
        {
            var newEvent = Event.Create(
                clubId, title, date, capacity);

            _repository.Add(newEvent);

            _notification.Send("Sự kiện mới: " + title);
        }
    }
}