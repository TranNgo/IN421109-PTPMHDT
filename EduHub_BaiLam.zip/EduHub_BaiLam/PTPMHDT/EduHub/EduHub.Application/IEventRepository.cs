﻿
using System;
using System.Collections.Generic;
using EduHub.Domain.Entities;

namespace EduHub.Application.Interfaces
{
    public interface IEventRepository
    {
        void Add(Event newEvent);

        Event GetById(Guid id);

        IEnumerable<Event> GetByClubId(Guid clubId);

        void Delete(Guid id);
    }
}
